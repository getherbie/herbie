---
title: Indepth
layout: doc
---

# Indepth

Thanks to its plugin system Herbie CMS is highly customizable and brings support for:

- Application Middlewares
- Route Middlewares
- Event Handlers
- Intercepting Filters
- Twig Filters
- Twig Globals
- Twig Functions
- Twig Tests
- Symfony Console Commands
