---
title: Plugins
layout: doc
---

# Plugins

Für Herbie CMS stehen schon einige Plugins zur Verfügung. 
Ein Plugin installiert man am einfachsten via Composer.

    $ composer require getherbie/plugin-disqus

Danach aktiviert man das Plugin in der Konfigurationsdatei und passt Plugin-Einstellungen nach Belieben an. 
Fertig!

[include path="@site/snippets/plugins.twig" linkto="dokumentation/plugins"]
