---
title: Development
---

# Development

[Herbie CMS at GitHub](https://github.com/getherbie/herbie)  
[Herbie CMS at Packagist](https://packagist.org/packages/getherbie/)

## Support

Support is given through GitHub. 
If possible, try to reproduce your issue before asking your question.

If you want to discuss the enhancement of Herbie CMS, file an [issue](https://github.com/getherbie/herbie/issues) on Github or submit a [pull request](https://github.com/getherbie/herbie).

## Bug Reports

If you find a bug, you can file an [issue](https://github.com/getherbie/herbie/issues).
